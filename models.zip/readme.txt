UFO model files for Madgraph.
f2d_n-plet_UFO: Dirac SU(2) doublet - neutral component chiN (chiN~), singly charged chip1 (chip1~)
f3m_n-plet_UFO: Majorana SU(2) triplet - neutral component chiN, singly charged chip1 (chip1~)
f5m_n-plet_UFO: Majorana SU(2) 5-plet - neutral component chiN, singly charged chip1 (chip1~), doubly charged chip2 (chip2~)
f7m_n-plet_UFO: Majorana SU(2) 7-plet - neutral component chiN, singly charged chip1 (chip1~), doubly charged chip2 (chip2~), triply charged chip3 (chip3~)